# Authors

Felix Grimm: fjg45
Nathnael Tesfaw: nbt26
Anthony Paredes-Bautista: ap2357
Maliq Barnes: db927

## Gen AI statement

Used AI to utilize the raylib library and read its documentations to do the GUI functions we wanted to. To convert the Phsyics to GUI compatable data, we used AI. We also used AI to create the graphics setup install.md file. We used AI to make test cases as well. AI was used to help with the initialization and design of the specific scenarios that can be loaded. AI also assisted in creating test cases for the physics engine to ensure 80% coverage. AI was assisted in utilizing the raylib librar (certain functions calls for our usecase). We used AI for comments for functions and AF/RIs.